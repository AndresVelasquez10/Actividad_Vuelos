package vuelos;

import controller.VueloController;
import vista.VueloView;

public class Vuelos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VueloController vueloController =new VueloController(new VueloView());
	}

}
