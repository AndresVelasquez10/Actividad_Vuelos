package modelo.dao;

import java.util.List;
import modelo.dto.Vuelo;

public class VueloDAO extends Persistencia<Vuelo> implements ICrud {

	public VueloDAO() {
            super("vuelos");
	// TODO Auto-generated constructor stub
	}

	@Override
	public boolean crear(Object object) {
		// TODO Auto-generated method stub
		boolean estado = lista.add((Vuelo) object);
		guardar();
		return estado;
	}

	@Override
	public Object leer(Object object) {
		// TODO Auto-generated method stub
            for (Vuelo vuelo : lista) {
                if(vuelo.getNumero() == ((Vuelo) object).getNumero())
                    return vuelo;
               }
            return null;
	}

	@Override
	public Object actualizar(int index, Object object) {
		// TODO Auto-generated method stub
            Object estado = lista.set(index,(Vuelo) object);
            guardar();
            return estado;
	}

	@Override
	public boolean eliminar(Object object) {
            // TODO Auto-generated method stub
            boolean estado = lista.remove(object);
            guardar();
            return estado;
	}

	@Override
	public int buscarIndex(Object object) {
            // TODO Auto-generated method stub
            return lista.indexOf(object);
	}

	@Override
	public List leerTodos() {
            // TODO Auto-generated method stub
            return lista;
	}

}
