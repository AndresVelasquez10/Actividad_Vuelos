package modelo.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Vuelo implements Serializable{
	private int numero;
	private String origen;
	private String destino;
	private Date fechaHoraSalida;
	private String areolinea;
	private Asiento[][] asientos;
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public String getAreolinea() {
		return areolinea;
	}
	public void setAreolinea(String areolinea) {
		this.areolinea = areolinea;
	}
	public Asiento[][] getAsientos() {
		return asientos;
	}
	public void setAsientos(Asiento[][] asientos) {
		this.asientos = asientos;
	}
	public Date getFechaHoraSalida() {
		return fechaHoraSalida;
	}
	public void setFechaHoraSalida(Date fechaHoraSalida) {
		this.fechaHoraSalida = fechaHoraSalida;
	}
	/**
	 * Genera una matriz de objetos de la clase Asiento
	 * @param fila
	 * @param asientosFila
	 */
	public void generarAsientos(int fila, int asientosFila) {
		asientos =new Asiento[fila][asientosFila];
		
		for (int i = 0; i < fila; i++) {
			char letra = 'A';
			for (int j = 0; j < asientosFila; j++) {
				Asiento asiento =new Asiento();
				asiento.setFila(i+1);
				asiento.setAsiento( (char) (letra+j));
				asiento.setPasajero(null);
				asientos[i][j] = asiento;
			}
		}
		
	}
}
