package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import modelo.dao.VueloDAO;
import modelo.dto.Asiento;
import modelo.dto.Pasajero;
import modelo.dto.Vuelo;
import vista.VueloView;

public class VueloController implements ActionListener{
	private VueloView vista;
	private VueloDAO modelo;
	private Vuelo vuelo;
	private int index;
	
	public VueloController(VueloView vista) {
		this.vista = vista;
                
		this.modelo =new VueloDAO();
                
		this.vista.actualizar.addActionListener(this);
		this.vista.crear.addActionListener(this);
		this.vista.eliminar.addActionListener(this);
		this.vista.leer.addActionListener(this);
                
		this.vista.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource().equals(this.vista.crear))
			crear();
		if(e.getSource().equals(this.vista.leer))
			leer();
		if(e.getSource().equals(this.vista.actualizar)) {
                    this.vista.fila.setEditable(false);
		    this.vista.asientosFila.setEditable(false);
                    actualizar();
		}	
		if(e.getSource().equals(this.vista.eliminar))
                    eliminar();
	}
	/**
	 * 
	 */
	public void crear() {
            Vuelo vuelo =new Vuelo();
            
            vuelo.setNumero(Integer.valueOf(this.vista.numero.getText()));
            vuelo.setOrigen(this.vista.origen.getSelectedItem().toString());
            vuelo.setDestino(this.vista.destino.getSelectedItem().toString());
            vuelo.setAreolinea(this.vista.aerolinea.getSelectedItem().toString());
            Date fechaHora = (Date) this.vista.fechaHora.getValue();
            vuelo.setFechaHoraSalida(fechaHora);
		
            int fila = Integer.valueOf(vista.fila.getText());
            int asientoFila = Integer.valueOf(vista.asientosFila.getText());
		
		
		//Se generar los asientos para el nuevo Vuelo
            vuelo.generarAsientos(fila, asientoFila);
            
            if(modelo.crear(vuelo))
                JOptionPane.showMessageDialog(null, "Un Nuevo Vuelo Fue Creado");
            else
                JOptionPane.showMessageDialog(null, "Yuca el Nuevo Vuelo No Se Puede Crear");
	}
	/**
	 * 
	 */
    public void leer() {
	vuelo =new Vuelo();
	vuelo.setNumero(Integer.valueOf(vista.numero.getText()));
	Vuelo vueloE = (Vuelo) modelo.leer(vuelo); 
	if(vueloE == null)
	   JOptionPane.showMessageDialog(null, "Yuca Error Vuelo No Existe");
	else {
	   index = modelo.buscarIndex(vueloE);	
	   this.vista.numero.setText(String.valueOf(vueloE.getNumero()));
	   this.vista.origen.setSelectedItem(vueloE.getOrigen());
	   this.vista.destino.setSelectedItem(vueloE.getDestino());
	   this.vista.aerolinea.setSelectedItem(vueloE.getAreolinea());
	   this.vista.fechaHora.setValue(vueloE.getFechaHoraSalida());
	   DefaultTableModel modeloTable;
		  
	   modeloTable = (DefaultTableModel) this.vista.tableAsientos.getModel();
		   
           Asiento[][] asientos = vueloE.getAsientos();
		   
	   int filas = modeloTable.getRowCount();
	       
	   for (int i = 0; i < filas; i++) {
	          modeloTable.removeRow(0);
	   }
	       
	   for (int i = 0; i < asientos.length; i++) {
         	   for (int j = 0; j < asientos[0].length; j++) {
			   
                 	Object[] fila = {asientos[i][j].getFila(),asientos[i][j].getAsiento(),asientos[i][j].getPasajero()==null ? "Disponible":"Ocupado"};
				modeloTable.addRow(fila);
	    	   }
	    	} 
		}
		
	}
	/**
	 * 
	 */
	public void actualizar() {
		int respuesta = JOptionPane.showConfirmDialog(null, "¿Estás seguro de Actualizar?", "Confirmar", JOptionPane.YES_NO_OPTION);
		if(respuesta == JOptionPane.YES_OPTION) {
			Vuelo vuelo =new Vuelo();
			vuelo.setNumero(Integer.valueOf(this.vista.numero.getText()));
			vuelo.setOrigen(this.vista.origen.getSelectedItem().toString());
			vuelo.setDestino(this.vista.destino.getSelectedItem().toString());
			vuelo.setAreolinea(this.vista.aerolinea.getSelectedItem().toString());
			Date fechaHora = (Date) this.vista.fechaHora.getValue();
			vuelo.setFechaHoraSalida(fechaHora);
			//Creo un objeto de la clase Vuelo
			Vuelo nuevoVuelo =new Vuelo();
						
			modelo.actualizar(index, vuelo);
		    JOptionPane.showMessageDialog(null,"Los Datos de un Vuelo fueron Modificados");
		    this.vista.fila.setEditable(true);
		    this.vista.asientosFila.setEditable(true);
		}
	}
	/**
	 * 
	 */
	public void eliminar() {
		int respuesta = JOptionPane.showConfirmDialog(null, "¿Estás seguro de Borrar?", "Confirmar", JOptionPane.YES_NO_OPTION);
		if(respuesta == JOptionPane.YES_OPTION) {
			if(modelo.eliminar(vuelo))
			 JOptionPane.showMessageDialog(null, "Vuelo Eliminado de la Data");
			else 
				JOptionPane.showMessageDialog(null, "Yuca Error Al Eliminar Vuelo");
		}
		
	}
        
        public void mostrarAsientos(){
           DefaultTableModel modeloTable;
		  
	   modeloTable = (DefaultTableModel) this.vista.tableAsientos.getModel();
		   
           Asiento[][] asientos = vuelo.getAsientos();
		   
	   int filas = modeloTable.getRowCount();
	       
	   for (int i = 0; i < filas; i++) {
	          modeloTable.removeRow(0);
	   }
	       
	   for (int i = 0; i < asientos.length; i++) {
         	for (int j = 0; j < asientos[0].length; j++) {
                    
                   int fila = asientos[i][j].getFila();
                   char letra = asientos[i][j].getAsiento();
                   String estado;
                   Pasajero pasajero = asientos[i][j].getPasajero();
                   
                   if(pasajero == null)
                       estado = "Disponible";
                   else
                       estado = "Ocupado";
			   
                   Object[] fila1 = {fila,letra,estado};
                 
                  //Object[] fila2 = {asientos[i][j].getFila(),asientos[i][j].getAsiento(),asientos[i][j].getPasajero()==null ? "Disponible":"Ocupado"};
		 
                   modeloTable.addRow(fila1);
	    	}
	    } 
        }
}

