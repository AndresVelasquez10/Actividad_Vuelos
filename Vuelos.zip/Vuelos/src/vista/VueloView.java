package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFormattedTextField;
import javax.swing.DropMode;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.util.Calendar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.ComponentOrientation;
import javax.swing.JScrollBar;
import java.awt.Dimension;

public class VueloView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTextField numero;
	public JComboBox origen;
	public JComboBox destino;
	private JLabel lblNewLabel;
	public JTextField fila;
	public JTextField asientosFila;
	public JSpinner fechaHora;
	public JButton crear;
	public JButton eliminar;
	public JButton actualizar;
	public JButton leer;
	public JComboBox aerolinea;
	public JTable tableAsientos;
	public JScrollPane scroll;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VueloView frame = new VueloView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VueloView() {
		initGUI();
	}

	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 581, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		numero = new JTextField();
		numero.setBounds(59, 20, 86, 20);
		contentPane.add(numero);
		numero.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Origen");
		lblNewLabel_1.setBounds(10, 48, 46, 14);
		contentPane.add(lblNewLabel_1);

		origen = new JComboBox();
		origen.setModel(new DefaultComboBoxModel(new String[] { "Bogota", "Barranquilla", "Bucaramanga", "Cali",
				"Cartagena", "Medellin", "Pasto", "Santa Marta" }));
		origen.setBounds(55, 44, 105, 22);
		contentPane.add(origen);

		JLabel lblNewLabel_2 = new JLabel("Destino");
		lblNewLabel_2.setBounds(10, 81, 46, 14);
		contentPane.add(lblNewLabel_2);

		destino = new JComboBox();
		destino.setModel(new DefaultComboBoxModel(new String[] { "Bogota", "Barranquilla", "Bucaramanga", "Cali",
				"Cartagena", "Medellin", "Pasto", "Santa Marta" }));
		destino.setSelectedIndex(2);
		destino.setBounds(59, 77, 101, 22);
		contentPane.add(destino);

		JLabel lblNewLabel_3 = new JLabel("Fecha");
		lblNewLabel_3.setBounds(10, 117, 46, 14);
		contentPane.add(lblNewLabel_3);

		lblNewLabel = new JLabel("Numero");
		lblNewLabel.setBounds(3, 23, 46, 14);
		contentPane.add(lblNewLabel);

		fechaHora = new JSpinner();
		fechaHora.setModel(new SpinnerDateModel(new Date(1762750800000L), null, null, Calendar.DAY_OF_YEAR));
		fechaHora.setBounds(49, 114, 135, 20);
		contentPane.add(fechaHora);

		JLabel lblNewLabel_4 = new JLabel("Aero linea");
		lblNewLabel_4.setBounds(10, 152, 71, 14);
		contentPane.add(lblNewLabel_4);

		aerolinea = new JComboBox();
		aerolinea.setModel(new DefaultComboBoxModel(new String[] { "Avianca", "JetSmart", "Latam", "Blue" }));
		aerolinea.setBounds(83, 152, 101, 22);
		contentPane.add(aerolinea);

		JLabel lblNewLabel_5 = new JLabel("Asientos");
		lblNewLabel_5.setBounds(10, 198, 46, 14);
		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("Filas");
		lblNewLabel_6.setBounds(59, 198, 37, 14);
		contentPane.add(lblNewLabel_6);

		fila = new JTextField();
		fila.setBounds(106, 195, 39, 20);
		contentPane.add(fila);
		fila.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("Asientos x Fila");
		lblNewLabel_7.setBounds(156, 198, 83, 14);
		contentPane.add(lblNewLabel_7);

		asientosFila = new JTextField();
		asientosFila.setBounds(249, 195, 39, 20);
		contentPane.add(asientosFila);
		asientosFila.setColumns(10);

		crear = new JButton("Crear");
		crear.setBounds(20, 227, 89, 23);
		contentPane.add(crear);

		eliminar = new JButton("Eliminar");
		eliminar.setBounds(116, 227, 89, 23);
		contentPane.add(eliminar);

		actualizar = new JButton("Actualizar");
		actualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		actualizar.setBounds(212, 227, 89, 23);
		contentPane.add(actualizar);

		leer = new JButton("Leer");
		leer.setBounds(155, 19, 89, 23);
		contentPane.add(leer);

		JLabel lblNewLabel_8 = new JLabel("Asientos");
		lblNewLabel_8.setBounds(390, 23, 59, 14);
		contentPane.add(lblNewLabel_8);

		tableAsientos = new JTable();
		tableAsientos.setMaximumSize(new Dimension(8, 6));
		tableAsientos.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Fila", "Asiento", "Estado" }));
		tableAsientos.setBounds(316, 48, 239, 164);
		scroll = new JScrollPane(tableAsientos);
		contentPane.add(scroll, BorderLayout.CENTER);
		contentPane.add(tableAsientos);
	}
}
